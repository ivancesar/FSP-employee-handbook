function openArticle(articleID) {
	$('.what_we_do_article').foreach(function(a){
		if (a.classList.contains('what_we_do_article_open')) a.classList.remove('what_we_do_article_open');
	});
	document.getElementById(articleID).classList.add('what_we_do_article_open');
}